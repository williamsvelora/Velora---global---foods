VELORA GLOBAL FOODS — FREE STATIC WEBSITE

Files:
- index.html: complete responsive website with CSS scroll reveal, slow image movement and marquee animation.

BEFORE PUBLISHING:
1. Open index.html in a text editor.
2. Find ADD-YOUR-EMAIL@example.com and replace it with your business email address.
3. Replace any image URLs if you have your own product photography.
4. Review all product descriptions and ensure they accurately reflect your current supply capability.

FREE HOSTING OPTIONS:
- GitHub Pages: create a public repository, upload index.html, then enable Pages in repository Settings.
- Netlify: sign up for a free account and drag the folder containing index.html into the manual deploy area.

The contact form opens the visitor's email app; it does not store submissions. For a hosted form inbox, connect a form service later.
